package launcher.combate_controlador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CombateControladorApplicationTests {

	@Test
	void contextLoads() {
	}

}
