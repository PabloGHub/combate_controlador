package launcher.combate_controlador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CombateControladorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CombateControladorApplication.class, args);
	}

}
